<template>
  <Nav />
  <About />
  <Project />
  <Footer />
</template>

<script setup>
import About from "./components/About/About.vue";
import Nav from "./components/Nav/Nav.vue"
import Project from "./components/Project/Project.vue";
import Footer from "./components/footer/footer.vue";
</script>

<style lang="scss" scoped>
</style>