<template>
  <div class="footer">
    <div class="footer-content">
      <div class="footer-content-info">
        <h3>Get in Touch With Us</h3>
        <div class="footer-content-info-link">
          <div class="logo">
            <img src="@/assets/img/logo.svg" alt="" />
          </div>
          <div class="geo">
            Uzbekistan, Chirchiq,<br />
            Troisk 3/7
          </div>
          <div class="contact">
            <span>
              <a href="tel:+998993983019">+998(99)938-30-19</a>
            </span>
            <div class="networks">
              <ul>
                <li>
                  <a
                    href="https://www.facebook.com/profile.php?id=100075042542116"
                    ><img src="@/assets/img/ff.svg" alt=""
                  /></a>
                </li>
                <li>
                  <a href="https://twitter.com/RustamKurb72196"
                    ><img src="@/assets/img/twiter.svg" alt=""
                  /></a>
                </li>
                <li>
                  <a href="https://www.instagram.com/kurbonboev.rrr/"
                    ><img src="@/assets/img/inst.svg" alt=""
                  /></a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
    <h2>© 2023. Ideapeel. Kurbonboev Rustam.</h2>
  </div>
</template>

<script setup>
</script>

<style lang="scss" scoped>
</style>