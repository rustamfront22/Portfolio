<template>
    <div class="header">
        <div class="header-content container">
            <div class="logo">
                <img src="@/assets/img/logo.svg" alt="">
            </div>
        </div>
    </div>
</template>

<script setup>
import { Icon } from '@iconify/vue';
</script>
