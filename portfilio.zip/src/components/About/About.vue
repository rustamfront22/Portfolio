<template>
    <div class="about">
        <div class="about-bg">
            <img src="@/assets/img/bg-about.png" alt="">

        </div>
        <div class="about-content container">
            <div class="about-content__info">
                <h1>Let’s get know <br> about me closer</h1>
                <p>Rustam is a front-end developer, lives in Uzbekistan. I specialize in web development and user interface design. My portfolio reflects my experience in creating visually appealing and interactive websites. With many years of experience, I work on various projects, including e-commerce platforms, responsive design and web applications. His skill set includes proficiency in HTML, CSS, JavaScript and frameworks such as Vue. I am passionate about creating a flawless user experience and following the latest industry trends. I am constantly striving for perfection, whether it is creating intuitive interfaces or optimizing the performance of a website. If you are looking for a talented frontend developer who can bring your ideas to life, Rustam is the perfect choice.</p>
            </div>
            <div class="about-content__img">
                <img src="@/assets/img/me.jpg" alt="">
            </div>
        </div>
    </div>
</template>

<script setup>

</script>

<style lang="scss" scoped>

</style>